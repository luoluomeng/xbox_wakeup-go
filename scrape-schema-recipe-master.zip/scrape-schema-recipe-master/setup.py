from setuptools import setup

# all the setup configuration is in the setup.cfg file
setup()
